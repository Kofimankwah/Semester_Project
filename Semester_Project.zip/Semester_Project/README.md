# Semester_Project
## Name:kofi Amankwah
## Program:Bsc.Information Tecnology ITB
## Index Number:UEB3248922
Project Description
## Online Exams System
This project is a complete Online Exam System written in C++. It is a web-based 
system that enables users to set up tests, administer tests, view and grade 
results, and analyze performance data. Users can set up tests with multiple 
questions, including objective and essay questions. A Timer for each test can be 
generated and can randomly select questions from a large pool of questions. It 
also allows users to leave comments on the test results for further analysis. The 
system also allows the administrator to publish test results and print out a 
summary. It records exam answers, multiple choice, and short answer questions, 
time spent, and marks obtained. With this system, users will be able to take the 
exams with ease and accuracy.
